from django.conf.urls import url
from report import views

urlpatterns = [
    url("", views.rhome, name='rhome'),
]
