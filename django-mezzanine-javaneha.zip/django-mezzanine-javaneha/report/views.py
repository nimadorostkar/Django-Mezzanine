from django.shortcuts import render
from report.models import report


def rhome(request):
    query = request.GET.get('name')
    template = "rhome.html"
    context = { 'report': report.objects.get(id_number=query) }
    return render(request, template, context)
