from django.db import models

class report(models.Model):
    name = models.CharField(default=" نام و نام خانوادگی ", max_length=40, unique=True)
    id_number = models.CharField(default=" شماره شناسنامه ", max_length=10, unique=True)
    rep_img = models.ImageField(upload_to='rep_img/%Y-%m-%d/')

    def __str__(self):
        return self.name
