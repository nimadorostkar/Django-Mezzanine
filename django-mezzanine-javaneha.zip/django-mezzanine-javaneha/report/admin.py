from django.contrib import admin
from report.models import report

admin.site.register(report)
